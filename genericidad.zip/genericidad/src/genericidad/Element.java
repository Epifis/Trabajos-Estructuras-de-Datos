package genericidad;
public class Element <T>{ //clase parametro
    public T[] content;
    private int size;
    private int actual;

    public Element() {
        this.content = (T[]) new Object[6];
        //(T[]) es un casting
    }
    public Element (T t){
        this.content[actual+1] = t;
        actual++;
    }

    public T getT(int index){
        return content[index];
    }

    public void setT(T t, int index) {
        this.content[actual++]=t;
    }
    
    
}
