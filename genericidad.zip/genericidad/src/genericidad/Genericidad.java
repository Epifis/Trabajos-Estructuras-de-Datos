package genericidad;

import java.util.ArrayList;

public class Genericidad {
    
    public static void main(String[] args) {
        ArrayList lista = new ArrayList();
        lista.add(777);
        lista.add("hii");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i) + " " + lista.get(i).getClass());
        }
        try{
            String texto = "";
            texto = (String) lista.get(0);
        }
        catch(Exception e){
            System.out.println("Error de casting: " + e.getMessage());
        }
        Object obj = lista.get(0);
        System.out.println("Valor object: " + obj.toString());
        
    }
}